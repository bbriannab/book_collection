import "@hotwired/turbo-rails"
import "@rails/ujs"

// Start Rails UJS
Rails.start();
